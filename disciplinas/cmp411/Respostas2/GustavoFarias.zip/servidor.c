#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>		
#include <arpa/inet.h>
#include <arpa/inet.h>         
#include <string.h>
#include <error.h>   
#define PORTNUMBER 2345

#include <pthread.h> // incluido

// cria a estrutura de dados que vai ser passada
struct thread_data {
   int sid; // identificação do socket
   struct sockaddr_in client; // estrutura com dados do cliente
};

// incluida função para tratamento da chamada no servidor
void * serverthread(void * param) {
   struct thread_data *par = (struct thread_data *) param; // conversão
   char buffer[100]; // buffer de entrada

   if (par->sid == 0) perror("Erro ao receber pedido de conexao: \n");
   else {
      printf("Conexao estabelecida com cliente %s.\n",inet_ntoa(par->client.sin_addr));

      //Lendo e imprimindo mensagem enviada pelo cliente
      int tamr = read(par->sid, buffer, 100);
      printf("Cliente %s enviou mensagem %s\n", inet_ntoa(par->client.sin_addr), buffer);
   }
}

int main(){
   int serversocket;
   int tamr;
   struct sockaddr_in server_addr;
   struct sockaddr_in client_addr;
   int connectionsocket;
   int socketsize;
   int flag;
    
   printf("Iniciando o servidor. \n");
   if ((serversocket = socket(AF_INET,SOCK_STREAM,0))<0)
      perror("Erro ao criar socket do servidor: \n");

   memset(&server_addr, 0, sizeof(server_addr));

   server_addr.sin_family = AF_INET;
   server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
   server_addr.sin_port = htons(PORTNUMBER);
   
   if (bind(serversocket, (struct sockaddr *)&server_addr, sizeof(struct sockaddr))<0)
      perror("Erro de ligacao de socket no servidor: \n");
   
   if (listen(serversocket, 1)<0) perror("Erro ao inicializar a escuta do socket no servidor: \n");
   
   printf("Servidor escutando na porta: %d .\n", PORTNUMBER);

   pthread_t st; // incluido. Declara a variavel id da thread
   struct thread_data param; // declara a estrutura para passar os dados

   while(1){
      socketsize = sizeof(client_addr);
      connectionsocket = accept(serversocket, (struct sockaddr *)&client_addr, &socketsize);
      
      // seta os valores da estrutura
      param.client = client_addr;
      param.sid = connectionsocket;

      // cria um a thread para tratar
      pthread_create(&st, NULL, (void*)serverthread, (void*)&param); // chamada da thread

      // prossegue o código, indefinidamente...
   }

}
