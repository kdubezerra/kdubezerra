#!/bin/sh
latex HOD.tex 
dvips -o HOD.ps HOD.dvi 
ps2pdf HOD.ps HOD.pdf
