//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by J2kDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_J2KDEMTYPE                  129
#define IDR_BMPTYPE                     129
#define IDR_JPGTYPE                     130
#define IDR_JPCTYPE                     131
#define IDR_JP2TYPE                     132
#define IDR_JPPTYPE                     133
#define IDD_RATE_DLG                    143
#define IDD_QUALITY_DLG                 144
#define IDD_USAGE_DLG                   145
#define IDI_BRUSH                       146
#define IDD_OPTION_DLG                  149
#define IDC_TRACKBAR1                   1000
#define IDC_STATIC_TRACK1               1003
#define IDC_RADIO1                      1005
#define IDC_RADIO2                      1006
#define ID_BUTTON32772                  32772
#define ID_BUTTON32773                  32773
#define ID_FILE_OPTION                  32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
