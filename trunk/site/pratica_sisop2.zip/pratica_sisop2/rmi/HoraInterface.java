import java.rmi.*;

public interface HoraInterface extends Remote {
   public String time() throws RemoteException;
}
