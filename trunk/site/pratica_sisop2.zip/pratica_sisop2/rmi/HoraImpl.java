import java.rmi.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HoraImpl
   extends java.rmi.server.UnicastRemoteObject
   implements HoraInterface {

   public HoraImpl() throws java.rmi.RemoteException {
      super();
   }

   public String time() {
      return new SimpleDateFormat("d MMM yyyy HH:mm:ss").format(new java.util.Date ());
   }

}