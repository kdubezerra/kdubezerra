    import java.rmi.*;

public class HoraServer {
  public static void main(String args[]) 
  {
    try {

      //Url atraves da qual o objeto sera acessao. Por exemplo: rmi://192.168.0.1/hora
      String url = args[0];

      //Cria o objeto que sera acessado remotamente
      HoraImpl hora = new HoraImpl();

      //Torna o objeto acessível a partir da rede
      Naming.rebind(url, hora);

      System.out.println("Hora remote object bound in the registry");

    } catch (Exception e) {
      System.out.println("HoraImpl error: " + e.getMessage());
      e.printStackTrace();
    }
  }
}
