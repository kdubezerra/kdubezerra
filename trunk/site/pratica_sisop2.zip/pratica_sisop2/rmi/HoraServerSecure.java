//java -Djava.security.policy=./java.policy HoraServer rmi://143.54.1.1/hora

import java.rmi.*;

public class HoraServerSecure {
   public static void main(String args[]) 
   {
      if (System.getSecurityManager() == null) {
         System.setSecurityManager(new RMISecurityManager());
      }

      try {

         //Url atraves da qual o objeto sera acessao. Por exemplo: rmi://192.168.0.1/hora
         String url = args[0];
         HoraImpl hora = new HoraImpl();

         // Bind this object instance to the name "HelloServer"
         Naming.rebind(url, hora);

         System.out.println("Hora remote object bound in the registry");
      } catch (Exception e) {
         System.out.println("HoraImpl error: " + e.getMessage());
         e.printStackTrace();
      }
   }
}
