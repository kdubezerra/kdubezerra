import java.rmi.*;

public class HoraClient {
   public static void main(String[] args) {

      //Armazena em url o endereco do objeto remoto, no formato rmi://endereço/objeto
      String url = args[0];

      try {

         //Pega uma referencia para o objeto remoto, localizado atraves do url
         HoraInterface hora_remota = (HoraInterface)Naming.lookup(url);

         //Acessa o metodo remoto e imprime o seu valor de retorno no console
         System.out.println( hora_remota.time() );

      } catch (Exception e) {
         System.out.println("Hora exception: " + e.getMessage());
         e.printStackTrace();
      }
   }
}