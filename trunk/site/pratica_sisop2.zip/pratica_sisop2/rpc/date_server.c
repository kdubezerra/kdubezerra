/**
 ** date_server.c
 **
 **/


#include <rpc/rpc.h>
#include <time.h>

long *bin_date_1_svc(void *argp, struct svc_req *rqstp) {
   static time_t timeval;

   timeval = time (NULL);
   return(&timeval);
}

char **str_date_1_svc(long *bintime, struct svc_req *rqstp) {
   static char *ptr;
   char        *ctime();

   ptr=ctime(bintime);
   return(&ptr);
}

/**
 ** cc -o date_svc date_server.c date_svc.c -lrpcsvc
 **
 **/
