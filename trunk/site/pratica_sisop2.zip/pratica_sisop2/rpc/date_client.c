/**
 ** date_client.c
 **
 **/

#include <stdio.h>
#include <rpc/rpc.h>
#include "date.h"

int main(int argc, char **argv) {
   CLIENT   *cl;
   char   *server;
   long   *lresult;
   char   **sresult;

   if (argc != 2) {
      fprintf(stderr,"usage: %s hostname\n", argv[0]);
      exit(1);
   }

   server=argv[1];

   if ((cl=clnt_create(server, DATE_PROG, DATE_VERS, "udp")) == NULL) {
      clnt_pcreateerror(server);
      exit(2);
   }

   if ((lresult = bin_date_1(NULL, cl)) == NULL) {
      clnt_perror(cl, server);
      exit(3);
   }

   printf("time on host %s = %ld\n", server, *lresult);

   if ((sresult = str_date_1(lresult, cl)) == NULL) {
      clnt_perror(cl, server);
      exit(4);
   }

   printf("time on host %s = %s\n", server, *sresult);

   clnt_destroy(cl);
   exit(0);
}

/**
 ** cc -o xdate date_client.c date_clnt.c -lrpcsvc
 **
 **/
